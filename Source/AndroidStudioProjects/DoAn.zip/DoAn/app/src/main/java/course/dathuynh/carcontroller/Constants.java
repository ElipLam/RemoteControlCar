package course.dathuynh.carcontroller;

public class Constants {

    //public static final String SERVER_URL = "http://13.58.108.38:2345";
    public static final String SERVER_IP = "13.58.108.38";
    public static final String SERVER_IP_LOCAL = "192.168.4.1";
    public static final int SERVER_PORT = 2345;

    public static final String URL_ChangePassword = "http://13.58.108.38/dieukhienxe/changepassword.php";
    public static final String URL_Login = "http://13.58.108.38/dieukhienxe/login.php";
    public static final String URL_SignUp = "http://13.58.108.38/dieukhienxe/registration.php";
    public static final String URL_GetCar = "http://13.58.108.38/dieukhienxe/availablecar.php";

    public static String PREFS_NAME = "loginpre";
    public static String PREF_USERNAME = "username";
    public static String PREF_PASSWORD = "password";

    public static String PREFS_NAME1 = "controlmode";
    public static String PREF_CONTROL = "controlmode";

}
